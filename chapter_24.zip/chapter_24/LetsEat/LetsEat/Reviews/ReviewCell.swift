//
//  ReviewCell.swift
//  LetsEat
//
//  Created by admin on 28/10/2019.
//  Copyright © 2019 MyName. All rights reserved.
//

import UIKit

class ReviewCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblReview: UILabel!
    @IBOutlet weak var ratingView: RatingsView!
}
