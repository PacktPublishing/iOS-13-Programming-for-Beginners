import UIKit

// Classes
// Creating a class declaration
class Transboremers {
    var name: String
    var altmode: String
    var active: Bool = true
    var attack: Int
    var health: Int
    
    // Class initializer
    init(name: String, altmode: String, attack: Int, health: Int){
        self.name = name
        self.altmode = altmode
        self.attack = attack
        self.health = health
    }
    
    func hit() {
        health -= 10
    }
    
    func description() -> String {
        return("name: \(self.name) altmode: \(self.altmode) active: \(self.active) attack: \(self.attack) health: \(self.health)")
    }
}

// Autoblot class, subclass of Transboremers
class Autoblot: Transboremers {
    let faction: String = "Autoblot"
    
    // overrides the description method in the superclass
    override func description() -> String {
        return("name: \(self.name) faction: \(self.faction) altmode: \(self.altmode) active: \(self.active) attack: \(self.attack) health: \(self.health)")
    }
}

// Making an instance of the class
let slobtimusGrime = Autoblot(name: "Slobtimus Grime", altmode: "Garbage Truck", attack: 10, health: 100)

// Printing out the property values
print(slobtimusGrime.description())

// Calling an instance method
slobtimusGrime.hit()
print(slobtimusGrime.description())

// Structures
// Creating a structure declaration

struct Deschlepticon {
    var name: String
    var faction: String
    var altmode: String
    var active: Bool
    var attack: Int
    var health: Int
    
    mutating func hit() {
        health -= 10
    }
    
    func description() -> String {
        return("name: \(self.name) faction: \(self.faction) altmode: \(self.altmode) active: \(self.active) attack: \(self.attack) health: \(self.health)")
    }
}

// Making an instance of the struct
var maggotron = Deschlepticon(name: "Maggotron", faction: "Deschlepticon", altmode: "maggot", active: true, attack: 10, health: 100)

// Calling the description method
print(maggotron.description())

// Calling an instance method
maggotron.hit()
print(maggotron.description())

// Value types vs reference types
// Value types
struct SampleValueType {
    var SampleProperty = 10
}
var a = SampleValueType()
var b = a
b.SampleProperty = 20
print(a.SampleProperty)
print(b.SampleProperty)

// Reference types
class SampleReferenceType {
    var SampleProperty = 10
}
var c = SampleReferenceType()
var d = c
d.SampleProperty = 20
print(c.SampleProperty)
print(d.SampleProperty)

// Enumerations
// Traffic light enumeration
enum TrafficLight {
    case red
    case yellow
    case green
    
    func trafficLightDescription() -> String {
        switch self {
        case .red:
            return "red"
        case .yellow:
            return "yellow"
        default:
            return "green"
        }
    }
}
// create a trafficLight variable
var trafficLight = TrafficLight.red
print(trafficLight.trafficLightDescription())







