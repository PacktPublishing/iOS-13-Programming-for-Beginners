//
//  ViewController.swift
//  Exploring Xcode
//
//  Created by admin on 08/06/2019.
//  Copyright © 2019 MyName. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func myButton(_ sender: UIButton) {
        print("Button clicked")
    }
}

