import UIKit

// Classes
// Creating a class declaration
class Animal {
    var name: String
    var sound: String
    var numberOfLegs: Int
    var breathesOxygen: Bool
    
    // Class initializer
    init(name: String, sound: String, numberOfLegs: Int, breathesOxygen: Bool){
        self.name = name
        self.sound = sound
        self.numberOfLegs = numberOfLegs
        self.breathesOxygen = breathesOxygen
    }
    
    func makeSound() {
        print(self.sound)
    }
    
    func description() -> String {
        return("name: \(self.name) sound: \(self.sound) numberOfLegs: \(self.numberOfLegs) breathesOxygen: \(self.breathesOxygen) ")
    }
}

// Mammal class, subclass of Animal
class Mammal: Animal {
    let hasFurOrHair: Bool = true
    
    // overrides the description method in the superclass
    override func description() -> String {
        return("Class: Mammal name: \(self.name) sound: \(self.sound) numberOfLegs: \(self.numberOfLegs) breathesOxygen: \(self.breathesOxygen) hasFurOfHair: \(self.hasFurOrHair) ")    }
}

// Making an instance of the class
let cat = Mammal(name: "Cat", sound: "Mew", numberOfLegs: 4, breathesOxygen: true)

// Printing out the property values
print(cat.description())

// Calling an instance method
cat.makeSound()

// Structures
// Creating a structure declaration

struct Reptile {
    var name: String
    var sound: String
    var numberOfLegs: Int
    var breathesOxygen: Bool
    let hasFurOrHair: Bool = false
    
    func makeSound() {
        print(sound)
    }
    
    func description() -> String {
        return("Class: Reptile name: \(self.name) sound: \(self.sound) numberOfLegs: \(self.numberOfLegs) breathesOxygen: \(self.breathesOxygen) hasFurOfHair: \(self.hasFurOrHair) ")    }}

// Making an instance of the struct
var snake = Reptile(name: "Snake", sound: "Hiss", numberOfLegs: 0, breathesOxygen: true)

// Printing out the property values
print(snake.description())

// Calling an instance method
snake.makeSound()

// Value types vs reference types
// Value types
struct SampleValueType {
    var SampleProperty = 10
}
var a = SampleValueType()
var b = a
b.SampleProperty = 20
print(a.SampleProperty)
print(b.SampleProperty)

// Reference types
class SampleReferenceType {
    var SampleProperty = 10
}
var c = SampleReferenceType()
var d = c
d.SampleProperty = 20
print(c.SampleProperty)
print(d.SampleProperty)

// Enumerations
// Traffic light enumeration
enum TrafficLight {
    case red
    case yellow
    case green
    
    func trafficLightDescription() -> String {
        switch self {
        case .red:
            return "red"
        case .yellow:
            return "yellow"
        default:
            return "green"
        }
    }
}
// create a trafficLight variable
var trafficLight = TrafficLight.red
print(trafficLight.trafficLightDescription())







