//
//  RestaurantCell.swift
//  LetsEat
//
//  Created by admin on 04/12/2019.
//  Copyright © 2019 MyName. All rights reserved.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblCuisine: UILabel!
    
    @IBOutlet weak var imgRestaurant: UIImageView!
    
}
