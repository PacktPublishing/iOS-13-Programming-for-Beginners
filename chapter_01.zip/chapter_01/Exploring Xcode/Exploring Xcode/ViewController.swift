//
//  ViewController.swift
//  Exploring Xcode
//
//  Created by John Applecore on 03/01/2020.
//  Copyright © 2020 MyName. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

