//
//  LocationDataManager.swift
//  LetsEat
//
//  Created by admin on 30/07/2019.
//  Copyright © 2019 MyName. All rights reserved.
//

import Foundation
